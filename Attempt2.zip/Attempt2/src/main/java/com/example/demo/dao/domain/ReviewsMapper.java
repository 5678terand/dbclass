package com.example.demo.dao.domain;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.Employee;
import com.example.demo.domain.Participator;
import com.example.demo.domain.Reviews;

@Mapper
public interface ReviewsMapper {

	@Select("SELECT REVEMAIL,PAPERID,TECHMERIT,READABILITY,ORIGINALITY,RELAVANCE,OVERALLRECOMM,COMMENTFORCOMMITTEE,COMMENTFORAUTHOR FROM REVIEWS")
	public List<Reviews> getRevList();
	

}

