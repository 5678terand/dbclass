package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.ConferenceDAO;
import com.example.demo.dao.ReviewsDAO;
import com.example.demo.domain.Participator;
import com.example.demo.domain.Reviews;

@Component
public class ReviewsService {

@Autowired
ReviewsDAO reviewsDAO; 

	public List<Reviews> getRevList() {
		List<Reviews> revList = new ArrayList<Reviews>();
		
		
		revList = reviewsDAO.getRevList();
		
		
		return revList;
		

	}

}

