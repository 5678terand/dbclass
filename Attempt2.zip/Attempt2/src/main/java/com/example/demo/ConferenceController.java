package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.domain.Employee;
import com.example.demo.domain.Participator;
import com.example.demo.domain.Reviews;
import com.example.demo.service.ParticipatorService;
import com.example.demo.service.ReviewsService;

@Controller
public class ConferenceController {
	
	private static final Logger logger = LoggerFactory.getLogger(ConferenceController.class);

	
	@Autowired
	ReviewsService revService;
	
	@Autowired
	ParticipatorService parService;
	
    @RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public String displayDashboard(Model model) {
    	
    //	List<Participator> partList = new ArrayList<Participator>();
    	List<Reviews> revList = new ArrayList<Reviews>();
    	   	
    	
   // 	partList = partService.getPartList();
    	revList = revService.getRevList();
    	
    //    model.addAttribute("partList",partList);
        model.addAttribute("revList",revList);
        return "dashboard";
    }
    
    @RequestMapping(value = "/participator", method = RequestMethod.GET)
    public String displayParticipator(Model model) {
    	
    	List<Participator> parList = new ArrayList<Participator>();
    	
    //empService = new EmployeeService();    	
    	
    	parList = parService.getParList();
    	
        model.addAttribute("parList",parList);
        return "parLanding";
    }
    
    @RequestMapping(value = "/Register", method = RequestMethod.GET)
    public String registerParticipator(@ModelAttribute Participator participator, Model model) {

    	participator = new Participator("","", "", "", "", "");
    	model.addAttribute("participator",participator);
 
        return "Register";
    }

    
    @RequestMapping(value = "/registerParticipator", method = RequestMethod.POST)
    public String saveParticipator(@ModelAttribute Participator participator, Model model) {

    	parService.registerParticipator(participator);
    	model.addAttribute("message","New Participator Registered Successfully");    	
    	model.addAttribute("participator",participator);

    	
        return "Register";
    }
}
