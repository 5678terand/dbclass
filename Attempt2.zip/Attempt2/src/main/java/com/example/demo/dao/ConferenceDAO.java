package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.domain.CompanyMapper;
import com.example.demo.dao.domain.ConferenceMapper;
import com.example.demo.domain.Employee;
import com.example.demo.domain.Participator;
import com.example.demo.domain.Reviews;

@Component
public class ConferenceDAO {
	@Autowired
	private ConferenceMapper conferenceMapper;
	
	public List<Participator> getParList() {
		
		List<Participator> parList = new ArrayList<Participator>();
		
		parList = conferenceMapper.getParList();
		
		return parList;
	}
	
	public List<Reviews> getRevList() {
		
		List<Reviews> revList = new ArrayList<Reviews>();
		
		revList = conferenceMapper.getRevList();
		
		return revList;
	}
	
	public void registerParticipator(Participator participator) {
		
		conferenceMapper.registerParticipator(participator);
		
	}


}
