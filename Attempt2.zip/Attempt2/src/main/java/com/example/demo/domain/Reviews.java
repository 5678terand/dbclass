package com.example.demo.domain;

public class Reviews {
	
	private String revemail;
	private int paperid;
	private int techmerit;
	private int readability;
	private int originality;
	private int relevance;
	private int overallrecomm;
	private String commentforcommittee;
	private String commentforauthor;
	
	public Reviews(String revemail, int paperid, int techmerit, int readability, int originality, int relevance,
			int overallrecomm, String commentforcommittee, String commentforauthor) {
		super();
		this.revemail = revemail;
		this.paperid = paperid;
		this.techmerit = techmerit;
		this.readability = readability;
		this.originality = originality;
		this.relevance = relevance;
		this.overallrecomm = overallrecomm;
		this.commentforcommittee = commentforcommittee;
		this.commentforauthor = commentforauthor;
	}
	public String getRevemail() {
		return revemail;
	}
	public void setRevemail(String revemail) {
		this.revemail = revemail;
	}
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	public int getTechmerit() {
		return techmerit;
	}
	public void setTechmerit(int techmerit) {
		this.techmerit = techmerit;
	}
	public int getReadability() {
		return readability;
	}
	public void setReadability(int readability) {
		this.readability = readability;
	}
	public int getOriginality() {
		return originality;
	}
	public void setOriginality(int originality) {
		this.originality = originality;
	}
	public int getRelevance() {
		return relevance;
	}
	public void setRelevance(int relevance) {
		this.relevance = relevance;
	}
	public int getOverallrecomm() {
		return overallrecomm;
	}
	public void setOverallrecomm(int overallrecomm) {
		this.overallrecomm = overallrecomm;
	}
	public String getCommentforcommittee() {
		return commentforcommittee;
	}
	public void setCommentforcommittee(String commentforcommittee) {
		this.commentforcommittee = commentforcommittee;
	}
	public String getCommentforauthor() {
		return commentforauthor;
	}
	public void setCommentforauthor(String commentforauthor) {
		this.commentforauthor = commentforauthor;
	}
	
	

}
