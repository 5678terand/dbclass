package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.ConferenceDAO;
import com.example.demo.dao.EmployeeDAO;
import com.example.demo.domain.Employee;
import com.example.demo.domain.Participator;

@Component
public class ParticipatorService {

@Autowired
ConferenceDAO conferenceDAO; 

	public List<Participator> getParList() {
		List<Participator> parList = new ArrayList<Participator>();
		
	
		parList = conferenceDAO.getParList();
		
		
		return parList;
		

	}
	public void registerParticipator(Participator participator) {
		
		conferenceDAO.registerParticipator(participator);
		
	}

}

