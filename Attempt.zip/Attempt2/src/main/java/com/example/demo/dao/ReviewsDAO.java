package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.domain.ReviewsMapper;

import com.example.demo.domain.Reviews;

@Component
public class ReviewsDAO {
	@Autowired
	private ReviewsMapper reviewsMapper;
	
	public List<Reviews> getRevList(){
		List<Reviews> revList = new ArrayList<Reviews>();
	
		revList = reviewsMapper.getRevList();
		
		return revList;
	}

}
