package com.example.demo.dao.domain;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.Employee;
import com.example.demo.domain.Participator;
import com.example.demo.domain.Reviews;

@Mapper
public interface ConferenceMapper {
	
	@Select("SELECT EMAIL,PASSWORD FROM PARTICIPATOR")
	public List<Employee> getLogin();
	
	@Select("SELECT EMAIL,FIRSTNAME, MINIT, LASTNAME, PHONE, AFFILIATION FROM PARTICIPATOR")
	public List<Participator> getParList();
	
	@Select("SELECT REVEMAIL,PAPERID,TECHMERIT,READABILITY,ORIGINALITY,RELAVANCE,OVERALLRECOMM,COMMENTFORCOMMITTEE,COMMENTFORAUTHOR FROM REVIEWS")
	public List<Reviews> getRevList();
	
	@Insert("insert into participator(email,firstname,minit,lastname,phone,affiliation,password) values (#{email}, #{firstname}, #{minit}, #{lastname}, #{phone}, #{affiliation},#{password} )")
	public void registerParticipator(Participator participator);
}

